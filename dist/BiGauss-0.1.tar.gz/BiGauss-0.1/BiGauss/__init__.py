# -*- coding: utf-8 -*-
"""
Created on Fri Jul  3 17:26:46 2020

@author: Fadjia Leila
"""

from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial
