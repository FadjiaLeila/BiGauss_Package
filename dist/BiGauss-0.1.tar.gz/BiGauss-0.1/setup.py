# -*- coding: utf-8 -*-
"""
Created on Fri Jul  3 17:21:48 2020

@author: Fadjia Leila
"""

from setuptools import setup 
setup(name ='BiGauss',
      version ='0.1',
      description ='Gaussian and Binomial distributions',
      packages = ['BiGauss'],
      author = 'Rose Fadjia Leila Joseph',
      auhor_email = 'fadjia20@gmail.com',
      zip_safe=False)